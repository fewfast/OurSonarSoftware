#include <Arduino.h>
#include <WiFi.h>
#include "./config/config.h"
#include "./network/wifi.h"
#include "./network/mqttx.h"
#include "./task/sonar.h"

void setup()
{
  Serial.begin(115200);

  xTaskCreate(
      connectWiFi,   // ฟังก์ชัน task
      "connectWiFi", // ชื่อ task
      4096,          // stack size
      NULL,          // parameter
      1,             // priority
      NULL           // task handle
  );
  xTaskCreate(mqttTask, "mqttTask", 4096, NULL, 1, NULL);
  xTaskCreate(sonarTask, "sonarTask", 4096, NULL, 1, NULL);
}

void loop()
{
  vTaskDelete(NULL); // ไม่ใช้ loop แล้ว
}