#include <Arduino.h>
#include <Servo.h>
#include "sonar.h"
#include "../network/mqttx.h"

#define SERVO_PIN 13
#define TRIG_PIN 5
#define ECHO_PIN 18

bool alertEnabled = true;

Servo radarServo;

float getDistance()
{
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(2);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);

    long duration = pulseIn(ECHO_PIN, HIGH, 30000); // timeout 30ms
    if (duration == 0)
        return -1; // ไม่มีสัญญาณ
    return duration * 0.034 / 2;
}

void sonarTask(void *pvParameters)
{
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);

    radarServo.attach(SERVO_PIN);
    radarServo.write(0);
    vTaskDelay(pdMS_TO_TICKS(1000));

    int angle = 0;
    int direction = 1; // 1 = เพิ่ม, -1 = ลด

    for (;;)
    {
        radarServo.write(angle);
        vTaskDelay(pdMS_TO_TICKS(50)); // รอ servo หมุนถึง

        float dist = getDistance();

        // สร้าง message แล้ว publish ไป MQTT
        char msg[50];
        if (dist > 0 && dist < 200)
        {
            snprintf(msg, sizeof(msg), "%d,%.1f", angle, dist);
        }
        else
        {
            snprintf(msg, sizeof(msg), "%d,OUT", angle);
        }
        mqttPublish("BeanNian/esp32/data", msg);

        // Serial log
        Serial.printf("📡 [%d°] %.1f cm\n", angle, dist);

        // หมุนไปเรื่อยๆ 0-180
        angle += direction * 2;
        if (angle >= 180)
        {
            angle = 180;
            direction = -1;
        }
        if (angle <= 0)
        {
            angle = 0;
            direction = 1;
        }
    }
}