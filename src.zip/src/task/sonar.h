#ifndef SONAR_H
#define SONAR_H

extern bool alertEnabled;

void sonarTask(void *pvParameters);

#endif