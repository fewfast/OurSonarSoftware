#include <WiFi.h>
#include "wifi.h"
#include "../config/config.h"

void connectWiFi(void *pvParameters)
{
    WiFi.begin(ssid, password);
    Serial.print("Connecting to WiFi");

    int retry = 0;
    while (WiFi.status() != WL_CONNECTED && retry < 20)
    {
        vTaskDelay(pdMS_TO_TICKS(500));
        Serial.print(".");
        retry++;
    }

    if (WiFi.status() == WL_CONNECTED)
    {
        Serial.println("\nWiFi connected!");
        Serial.print("IP: ");
        Serial.println(WiFi.localIP());
    }
    else
    {
        Serial.println("\nWiFi failed! Restarting...");
        ESP.restart(); // restart ถ้าต่อไม่ได้
    }
    vTaskDelete(NULL);
}