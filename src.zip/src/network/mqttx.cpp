#include <WiFi.h>
#include <PubSubClient.h>
#include <Servo.h>
#include "mqttx.h"
#include "../config/config.h"
#include "../task/sonar.h"

WiFiClient espClient;
PubSubClient client(espClient);
extern Servo radarServo;

void callback(char *topic, byte *payload, unsigned int length)
{
    String message = "";
    for (int i = 0; i < length; i++)
        message += (char)payload[i];

    Serial.printf("📩 [%s]: %s\n", topic, message.c_str());

    if (String(topic) == "BeanNian/esp32/config")
    {

        // แยก key:value
        int sep = message.indexOf(':');
        if (sep == -1)
            return; // format ผิด

        String key = message.substring(0, sep);    // เช่น "servo"
        String value = message.substring(sep + 1); // เช่น "ON"

        if (key == "servo")
        {
            if (value == "ON")
            {
                radarServo.attach(13);
                Serial.println("✅ Servo ON");
            }
            else if (value == "OFF")
            {
                radarServo.detach();
                Serial.println("✅ Servo OFF");
            }
        }
        else if (key == "alert")
        {
            if (value == "ON")
            {
                alertEnabled = true;
                Serial.println("🔔 Alert ON");
            }
            else if (value == "OFF")
            {
                alertEnabled = false;
                Serial.println("🔕 Alert OFF");
            }
        }
        else if (key == "mode")
        {
            Serial.printf("🔄 Mode: %s\n", value.c_str());
            // เพิ่ม logic mode ทีหลัง
            if (value == "ROAM")
            {
                radarServo.attach(13);
                Serial.println("✅ Servo ON");
            }
            else if (value == "TRACK")
            {
                radarServo.detach();
                Serial.println("✅ Servo OFF");
            }
            else if (value == "STATIC")
            {
                radarServo.detach();
                Serial.println("✅ Servo OFF");
            }
        }
    }
}

void reconnect()
{
    while (!client.connected())
    {
        Serial.print("Connecting to MQTT...");
        if (client.connect("ESP32_BeanNian_001"))
        {
            Serial.println("MQTT connected!");
            mqttPublish("BeanNian/esp32/status", "ESP32-Connected");
            client.subscribe("BeanNian/esp32/config");
        }
        else
        {
            Serial.print("failed, rc=");
            Serial.println(client.state());
            vTaskDelay(pdMS_TO_TICKS(2000));
        }
    }
}

void mqttTask(void *pvParameters)
{
    // รอ WiFi ก่อน
    while (WiFi.status() != WL_CONNECTED)
        vTaskDelay(pdMS_TO_TICKS(500));

    vTaskDelay(pdMS_TO_TICKS(1000));

    client.setServer(mqtt_server, mqtt_port);
    client.setCallback(callback);

    for (;;)
    {
        if (!client.connected())
            reconnect();

        client.loop();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void mqttPublish(const char *topic, const char *message)
{
    if (client.connected())
        client.publish(topic, message);
}