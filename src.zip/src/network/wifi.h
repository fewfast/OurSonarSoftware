#ifndef WIFI_MANAGER_H // ถ้า WIFI_MANAGER_H ยังไม่ถูก define...
#define WIFI_MANAGER_H // ...ให้ define มัน แล้วอ่านโค้ดข้างในได้

void connectWiFi(void *pvParameters);

#endif // จบแค่นี้