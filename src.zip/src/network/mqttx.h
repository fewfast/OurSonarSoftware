#ifndef MQTTX_H
#define MQTTX_H

void mqttTask(void *pvParameters);
void mqttPublish(const char *topic, const char *message);

#endif