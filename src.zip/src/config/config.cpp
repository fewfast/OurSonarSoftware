#include "config.h"

const char *ssid = "Bean Nian";
const char *password = "Fugelplus";
const char *mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;